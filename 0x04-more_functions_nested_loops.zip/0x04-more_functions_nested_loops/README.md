 Today on the 15th of september, I Eric will doing c programming
0X04. C- more functions, more nested loops
started at : 3.27.
